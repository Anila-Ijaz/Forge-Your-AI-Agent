<div align="center">

# ⚒️ Forge

### Your Local AI Agent — Build Anything, Run Anywhere

**A fully local, open-source AI agent that builds software, browses the web, executes code, and gets real work done — all powered by Ollama on your own machine.**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![Ollama](https://img.shields.io/badge/powered%20by-Ollama-black)](https://ollama.com)
[![FastAPI](https://img.shields.io/badge/backend-FastAPI-009688)](https://fastapi.tiangolo.com/)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](https://github.com/yourusername/forge/pulls)

[Features](#-features) • [Quick Start](#-quick-start) • [How It Works](#-how-it-works) • [Examples](#-examples) • [Configuration](#%EF%B8%8F-configuration) • [Contributing](#-contributing)

</div>

---

## 🌟 What is Forge?

Forge is a **ChatGPT-style AI agent that runs entirely on your own computer**. Unlike cloud-based assistants, your conversations, code, and data never leave your machine. Ask it to build a game, create a website, write a script, search the web, or run shell commands — Forge actually does it by calling real tools, not just talking about them.

> Think of Forge as a self-hosted Claude Code or Cursor agent: same agentic capabilities, zero cloud dependency, no API costs.

## ✨ Features

- 🧠 **100% Local** — runs on Ollama. Your data never leaves your machine. No API keys, no subscriptions.
- 🛠️ **Real Agentic Tool Use** — writes files, runs shell commands, searches the web, fetches pages — not just text generation.
- 💬 **Beautiful Chat UI** — dark-themed, streaming responses, live workspace file viewer, mobile-friendly.
- 📁 **Sandboxed Workspace** — all file operations safely contained in a `workspace/` directory.
- 🌐 **Real-time Web Access** — DuckDuckGo search and page fetching built in for current info.
- 🔄 **Resilient Agent Loop** — auto-recovers from weak models that "leak" tool calls as text.
- 🎨 **Identity-aware** — knows it's Forge, admits when it doesn't know things, uses real-time data when needed.
- 🔌 **Extensible** — add new tools in ~10 lines of Python.

## 🎯 What Can Forge Build?

Ask Forge things like:

| Prompt | What Forge Does |
|--------|----------------|
| *"Build a Snake game as one HTML file"* | Creates `workspace/snake.html` with full game logic |
| *"Make a dark-themed portfolio site"* | Generates a styled `index.html` with sections, animations |
| *"Search for the latest Llama model news"* | Calls `web_search` + summarizes results |
| *"Write a Python script to rename all images in this folder"* | Creates the script and explains how to run it |
| *"Set up a basic Express server with a /hello endpoint"* | Writes the code, runs `npm install`, starts it |
| *"What's the weather in Berlin?"* | Searches the web for current weather data |

## 🚀 Quick Start

### Prerequisites

1. **Python 3.9+** — [download](https://python.org)
2. **Ollama** — [download](https://ollama.com)
3. A capable model (one-time download):
   ```bash
   ollama pull qwen2.5:7b      # recommended — 4.7 GB, needs 8 GB RAM
   # or for stronger machines:
   ollama pull qwen2.5:14b     # ~9 GB, needs 16 GB RAM
   ```

> ⚠️ **Model matters!** Forge needs a model that supports tool calling. Llama 3.1, Qwen 2.5, and Mistral Nemo all work well. Older models (Llama 2, Phi-2) won't.

### Install & Run

```bash
# Clone the repo
git clone https://github.com/yourusername/forge.git
cd forge

# Install dependencies
pip install -r backend/requirements.txt

# Start Forge
python backend/server.py        # any OS
# or:
./run.sh                        # Linux / macOS
run.bat                         # Windows
```

Open **http://localhost:8000** in your browser. That's it. 🎉

## 🧩 How It Works

```
┌─────────────────┐      ┌──────────────────┐      ┌─────────────┐
│  Browser (UI)   │◄────►│  FastAPI Server  │◄────►│   Ollama    │
│  Chat + Files   │ SSE  │  Agent Loop      │ HTTP │ (Local LLM) │
└─────────────────┘      └────────┬─────────┘      └─────────────┘
                                  │
                         ┌────────▼──────────┐
                         │   Tool Registry   │
                         │ ─────────────────  │
                         │ • write_file      │
                         │ • read_file       │
                         │ • run_shell       │
                         │ • web_search      │
                         │ • web_fetch       │
                         └───────────────────┘
```

1. You type a request in the browser.
2. The frontend streams it to the backend via Server-Sent Events.
3. The backend sends your conversation + available tools to Ollama.
4. If the model returns tool calls, Forge executes them locally and feeds results back.
5. The loop repeats until the model produces a final answer.
6. The UI shows each step live: thinking, tool calls, results, and updated workspace files.

## 💡 Examples

### Build a game

> **You:** Build a Tetris game as a single HTML file with neon colors.

Forge writes `workspace/tetris.html` with the full game. Open it in your browser — playable instantly.

### Use your own resume to build a portfolio

> **You:** *[pastes resume]* Now build me a single-page portfolio using this info.

Forge extracts your real name, skills, projects, and creates a styled `workspace/portfolio/index.html`.

### Get real-time information

> **You:** Search the web for the top 3 open-source LLMs released this month and summarize each.

Forge calls `web_search`, fetches articles, summarizes — all visible in the chat.

## ⚙️ Configuration

Set environment variables before running:

```bash
export FORGE_MODEL="qwen2.5:14b"             # default: llama3.1
export OLLAMA_HOST="http://localhost:11434"  # default: localhost
export FORGE_WORKSPACE="/path/to/workspace"  # default: ./workspace
python backend/server.py
```

On Windows:

```cmd
set FORGE_MODEL=qwen2.5:7b
run.bat
```

## 📂 Project Structure

```
forge/
├── backend/
│   ├── server.py          # FastAPI server with streaming chat endpoint
│   ├── agent.py           # Multi-step agent loop with tool execution
│   ├── tools.py           # Sandboxed tools: files, shell, web
│   └── requirements.txt
├── frontend/
│   └── index.html         # Single-file chat UI (HTML + CSS + JS)
├── workspace/             # Where the agent creates files (sandboxed)
├── run.sh                 # Linux/macOS launcher
├── run.bat                # Windows launcher
├── TROUBLESHOOTING.md     # Common issues & model recommendations
└── README.md
```

## 🔧 Extending Forge

Add a new tool in `backend/tools.py`:

```python
# 1. Write the function
def get_random_quote() -> dict:
    import random
    quotes = ["The best way to predict the future is to invent it.", ...]
    return {"success": True, "quote": random.choice(quotes)}

# 2. Register it in TOOLS_SCHEMA
{
    "type": "function",
    "function": {
        "name": "get_random_quote",
        "description": "Get an inspirational quote.",
        "parameters": {"type": "object", "properties": {}},
    },
}

# 3. Add it to TOOL_FUNCTIONS
TOOL_FUNCTIONS["get_random_quote"] = get_random_quote
```

That's it — the agent discovers it automatically.

## 🛡️ Safety Notes

- **Sandboxed file ops:** all file paths are validated to stay inside `workspace/`. Escape attempts (`../../etc/passwd`) are rejected.
- **Shell execution warning:** `run_shell` runs commands as your user. If you don't fully trust the model's output, run Forge inside a Docker container or VM.
- **Web requests:** all web fetches go through your machine's network. Review fetched content before acting on it.

## 🎨 Recommended Models

| Model | Size | Min RAM | Tool-calling Quality |
|-------|------|---------|---------------------|
| `qwen2.5:14b` | 9 GB | 16 GB | ⭐⭐⭐⭐⭐ Best |
| `llama3.1:8b` | 4.7 GB | 8 GB | ⭐⭐⭐⭐ Excellent |
| `qwen2.5:7b` | 4.7 GB | 8 GB | ⭐⭐⭐⭐ Excellent |
| `mistral-nemo` | 7 GB | 12 GB | ⭐⭐⭐⭐ Great |
| `qwen2.5:3b` | 2 GB | 4 GB | ⭐⭐ Works but weaker |
| `llama3.2:3b` | 2 GB | 4 GB | ⭐⭐ Works but weaker |

## 🐛 Troubleshooting

See **[TROUBLESHOOTING.md](TROUBLESHOOTING.md)** for solutions to common issues:
- "Connection error: Failed to fetch"
- Agent dumps raw JSON instead of creating files
- "Reached max iterations" errors
- Tips for getting better results

## 🤝 Contributing

Contributions are welcome! Here's how to help:

1. 🍴 Fork the repo
2. 🌿 Create a feature branch (`git checkout -b feature/amazing-tool`)
3. ✨ Commit your changes (`git commit -m 'Add amazing tool'`)
4. 🚀 Push to the branch (`git push origin feature/amazing-tool`)
5. 🎉 Open a Pull Request

Areas where we'd love help:
- Additional tools (image generation, PDF parsing, database queries)
- Conversation history persistence
- Multi-session support
- Docker container for safe shell execution
- Better small-model support
- Voice input/output

## 📜 License

This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

Built with:
- [Ollama](https://ollama.com) — local LLM serving
- [FastAPI](https://fastapi.tiangolo.com/) — backend framework
- [DuckDuckGo Search](https://github.com/deedy5/duckduckgo_search) — web search
- Vanilla JavaScript — no frontend frameworks needed

Inspired by the great work on Claude Code, Cursor, OpenInterpreter, and the broader local-LLM community.

## ⭐ Star History

If you find Forge useful, please consider giving it a star! It helps others discover the project.

---

<div align="center">

**Built with ❤️ by developers who believe AI should run on your own hardware.**

[Report Bug](https://github.com/yourusername/forge/issues) · [Request Feature](https://github.com/yourusername/forge/issues) · [Discussions](https://github.com/yourusername/forge/discussions)

</div>
