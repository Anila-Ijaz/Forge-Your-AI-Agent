# Contributing to Forge

First off — thanks for considering contributing to Forge! 🎉

Forge is a community project, and we welcome contributions of all kinds: bug reports, feature requests, documentation improvements, and code.

## 🐛 Reporting Bugs

Before creating a bug report, please:

1. **Check existing issues** — your problem may already be reported.
2. **Try the latest version** — pull the latest changes from `main`.
3. **Reproduce it** — make sure the bug is reproducible.

When opening a bug report, include:
- Your OS (Windows / macOS / Linux)
- Python version (`python --version`)
- Ollama model you're using (`ollama list`)
- Steps to reproduce
- Expected vs actual behavior
- Console / terminal output if relevant

## 💡 Suggesting Features

We love feature ideas! Open an issue with:
- A clear description of the feature
- Why it would be useful
- Example use cases
- (Optional) Implementation ideas

## 🔧 Code Contributions

### Setup for development

```bash
git clone https://github.com/yourusername/forge.git
cd forge
pip install -r backend/requirements.txt
python backend/server.py
```

### Adding a new tool

Tools are the main way to extend Forge. To add one:

1. Open `backend/tools.py`
2. Write a function that takes simple arguments and returns a `dict` with at least `{"success": bool, ...}`
3. Add a JSON schema entry in `TOOLS_SCHEMA`
4. Register the function in `TOOL_FUNCTIONS`

Example:
```python
def my_new_tool(arg1: str) -> dict:
    try:
        # do something
        return {"success": True, "result": "..."}
    except Exception as e:
        return {"success": False, "error": str(e)}

# Add schema
{
    "type": "function",
    "function": {
        "name": "my_new_tool",
        "description": "Clear description so the model knows when to call it.",
        "parameters": {
            "type": "object",
            "properties": {"arg1": {"type": "string"}},
            "required": ["arg1"],
        },
    },
}

# Register
TOOL_FUNCTIONS["my_new_tool"] = my_new_tool
```

### Code style

- Follow PEP 8 for Python
- Keep functions small and focused
- Add docstrings to public functions
- Comment non-obvious logic
- Frontend: keep it vanilla JS — no frameworks

### Pull Request Process

1. Fork the repo and create a feature branch (`feature/your-feature`)
2. Make your changes
3. Test that the server still starts and the agent works
4. Update the README if you add user-facing features
5. Commit with a clear message: `Add: image generation tool` or `Fix: tool call extraction for multi-line JSON`
6. Push and open a Pull Request

## 📜 Code of Conduct

Be kind, be respectful, assume good intent. No harassment, discrimination, or personal attacks. We're all here to build cool stuff together.

## ❓ Questions?

Open a discussion in the [Discussions](https://github.com/yourusername/forge/discussions) tab — happy to help!
