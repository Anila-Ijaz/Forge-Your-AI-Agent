# GitHub Repository Setup — Copy-Paste Cheatsheet

Everything you need to set up the Forge repo on GitHub in one place.

---

## 📝 Repository Description (for the "About" section)

**Pick one** — copy-paste it into GitHub's repo settings:

### Short (recommended, fits in repo header)
```
A fully local, open-source AI agent powered by Ollama. Builds software, browses the web, runs code — all on your own machine. ⚒️
```

### Medium
```
Forge is a ChatGPT-style AI agent that runs entirely locally. It writes files, runs shell commands, searches the web, and gets real work done — powered by Ollama. No cloud, no API keys, no subscriptions.
```

### Tagline only (for the website / hero)
```
Your local AI agent — build anything, run anywhere.
```

---

## 🏷️ Topics / Tags (add these to the repo)

Click the gear icon next to "About" on your GitHub repo and add these topics:

```
ai-agent
ollama
local-llm
llm
ai
python
fastapi
chatbot
agent
open-source
self-hosted
chatgpt-alternative
claude-alternative
tool-use
function-calling
llama
qwen
mistral
ai-assistant
code-generation
```

---

## 🌐 Website URL (optional)

If you set up a demo page later, link it. Otherwise leave it empty for now.

---

## 📸 Social Preview Image

GitHub shows a preview image when your repo is shared on social media. Recommended:
- **Size:** 1280 × 640 pixels
- **Content:** Forge logo + tagline + a screenshot of the UI
- **Upload:** Settings → Social preview → Upload an image

If you want, I can describe what to put in the image — but you'd need to design it in Canva / Figma / Photoshop.

---

## 🚀 Initial Git Commands

After creating the empty repo on GitHub, in your local `forge` folder:

```bash
git init
git add .
git commit -m "Initial commit: Forge — local AI agent powered by Ollama"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/forge.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your actual GitHub username.

---

## 📋 Recommended Repo Settings

After pushing, configure these in GitHub repo settings:

### Features to enable
- ✅ Issues
- ✅ Discussions (great for Q&A)
- ✅ Wiki (optional)
- ❌ Projects (unless you'll use them)

### Branch protection (for `main`)
- Require pull request reviews
- Require status checks (once you add CI later)

### Security
- Enable Dependabot alerts
- Enable secret scanning

---

## 📌 Pin to Your Profile

Once published, pin Forge to your GitHub profile so it shows up first:
- Go to your profile → Customize your pins → Select Forge

---

## 🎯 First README Improvements After Publishing

Once the repo is live, update the README:

1. **Replace `yourusername`** with your actual GitHub username in all links
2. **Add a screenshot** at the top — take a clean shot of Forge building something cool
3. **Add a demo GIF** — record a 10-15 second demo of asking it to build a game (use ScreenToGif on Windows or Kap on Mac)
4. **Add badges** for stars, forks, issues as the repo grows:
   ```markdown
   ![GitHub stars](https://img.shields.io/github/stars/YOUR-USERNAME/forge?style=social)
   ![GitHub forks](https://img.shields.io/github/forks/YOUR-USERNAME/forge?style=social)
   ![GitHub issues](https://img.shields.io/github/issues/YOUR-USERNAME/forge)
   ```

---

## 🎤 Where to Share It

After publishing, share Forge to get visibility:

- **Reddit:** r/LocalLLaMA, r/Python, r/SideProject, r/opensource
- **Hacker News:** submit to "Show HN"
- **X / Twitter:** post with screenshots/demo + tag @ollama
- **Product Hunt:** great for indie projects
- **Dev.to / Hashnode:** write a launch blog post

Suggested launch tweet:
> Just open-sourced ⚒️ Forge — a local AI agent that builds software, browses the web, and runs code on your own machine. No API keys, no cloud. Powered by @ollama. Check it out 👇 [link]

---

Good luck with the launch! 🚀
